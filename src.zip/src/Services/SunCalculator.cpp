#include "SunCalculator.hpp"
#include <cmath>
#include <algorithm>

SunPosition SunCalculator::compute(const BalconyConfig& cfg) {
    float timezone = std::round(cfg.longitude / 15.0f);
    float hourUTC = cfg.hour - timezone;
    
    float d = (float)cfg.day + 30.6f * (cfg.month + 1) + (cfg.year - 2000) * 365.25f; 
    float g = toRad(357.529f + 0.9856003f * d);
    float q = 280.459f + 0.9856474f * d;
    float L = q + 1.915f * std::sin(g) + 0.020f * std::sin(2.0f * g);
    float R = toRad(L);
    float eps = toRad(23.439f - 0.0000004f * d);
    
    float dec = std::asin(std::sin(eps) * std::sin(R));
    float RA = toDeg(std::atan2(std::cos(eps) * std::sin(R), std::cos(R))) / 15.0f;
    
    float lst = (100.46f + 0.985647f * d + cfg.longitude + 15.0f * hourUTC) / 15.0f;
    float ha = toRad(15.0f * (lst - RA));
    float lat = toRad(cfg.latitude);

    float sAlt = std::sin(lat) * std::sin(dec) + std::cos(lat) * std::cos(dec) * std::cos(ha);
    float alt = std::asin(sAlt);
    
    float cAz = (std::sin(dec) - std::sin(lat) * sAlt) / (std::cos(lat) * std::cos(alt));
    float az = toDeg(std::acos(std::clamp(cAz, -1.0f, 1.0f)));
    if (std::sin(ha) > 0) az = 360.0f - az;

    return { az, toDeg(alt) };
}

bool SunCalculator::isInShadow(const BalconyConfig& cfg, int tx, int ty, const SunPosition& sun) {
    if (!sun.isAboveHorizon()) return true;

    float cellSizeM = 0.05f; 
    float bAz = static_cast<float>(cfg.orientation) * 45.0f;
    float relAz = toRad(sun.azimuth - bAz);
    
    sf::Vector2f sunDir(-std::sin(relAz), std::cos(relAz));
    float tanElev = std::tan(toRad(sun.elevation));

    // 1. TOIT
    if (cfg.hasRoof) {
        float distHorizM = 2.5f / tanElev;
        float sourceX = (tx * cellSizeM) + (sunDir.x * distHorizM);
        float sourceY = (ty * cellSizeM) + (sunDir.y * distHorizM);

        if (sourceX >= 0 && sourceX < cfg.width * cellSizeM &&
            sourceY >= 0 && sourceY < cfg.height * cellSizeM) {
            return true; 
        }
    }

    // 2. MURS (Rayon unique, pas très fin pour boucher les diagonales)
    float startX = tx + 0.5f;
    float startY = ty + 0.5f;

    for (float d = 0.10f; d < 100.0f; d += 0.10f) {
        int cx = static_cast<int>(startX + sunDir.x * d);
        int cy = static_cast<int>(startY + sunDir.y * d);

        if (cx < 0 || cx >= cfg.width || cy < 0 || cy >= cfg.height) break;
        if (cx == tx && cy == ty) continue; 

        const auto& cell = cfg.grid[cy][cx];
        if (cell.isWall) {
            float distMetres = d * cellSizeM;
            if (cell.wallHeight / distMetres > tanElev) return true;
        }
    }

    return false;
}