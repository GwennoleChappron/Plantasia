#pragma once
#include "Core/State.hpp"
#include "Core/Application.hpp"
#include <vector>

// Les différents outils de notre éditeur
enum class EditMode {
    OBSERVER,
    PLACER_PLANTE,
    DESSINER_MUR
};

class StateBalconySim : public State {
private:
    float m_heureDuJour = 12.0f; 
    
    // --- PARAMÈTRES DE LA GRILLE ---
    // 1 case = 5x5 cm physiques = 15x15 pixels à l'écran
    float m_gridCellSize = 15.0f; 
    sf::Vector2f m_balconPos = {350.f, 150.f}; // Décalé à droite pour laisser la place à l'UI
    sf::Vector2i m_balconGridSize = {40, 30};  // Un balcon de 200x150 cm (40*5, 30*5)
    std::vector<float> m_sunScores; // Score de 0 (ombre) à 1 (plein soleil) pour chaque case
    void recalculerOmbres();

    // --- ÉTAT DE L'ÉDITEUR ---
    EditMode m_currentMode = EditMode::OBSERVER;
    int m_selectedPlantIndex = -1;

public:
    StateBalconySim(Application* app);
    
    void onEnter() override;
    void onExit() override;
    void update(float dt) override;
    void draw(sf::RenderWindow& window) override;
    void drawImGui() override;
};