#pragma once
#include "Core/State.hpp"
#include "Data/BalconyConfig.hpp"
#include "Services/SunCalculator.hpp"
#include <SFML/Graphics.hpp>

class StateBalconySim : public State {
private:
    BalconyConfig m_cfg;
    SunPosition   m_sun;           
    bool          m_sunMapDirty = true;  

    int  m_editMode = 0;            
    int  m_selectedPlantIndex = -1; 
    bool m_showSunMap    = false;   
    bool m_showShadows   = true;    
    const float CELL_PX  = 15.0f;   

    // --- NOUVEAU : SOLVER GPU POUR LA HEATMAP ---
    sf::Texture       m_wallTexture;   // La grille convertie en pixels pour le GPU
    sf::RenderTexture m_sunmapTexture; // La toile d'accumulation des heures de soleil
    sf::Shader        m_raycastShader; // Le shader qui fait le raycasting
    sf::Shader        m_heatmapShader; // Le shader qui colorie la heatmap
    bool              m_shadersLoaded = false;
    
    void updateWallTexture();
    void computeSunMapGPU();

    void handleInput();
    void drawCompass();              
    void recalcSun();
    void markSunMapDirty();
    sf::VertexArray m_gridVertices;
    void updateGridVertices();
    void renderGrid(sf::RenderWindow& window, sf::Vector2f offset);
    void renderShadowLayer(sf::RenderWindow& window, sf::Vector2f offset);
    void renderSunMapLayer(sf::RenderWindow& window, sf::Vector2f offset);
    void renderPlants(sf::RenderWindow& window, sf::Vector2f offset);

public:
    StateBalconySim(Application* app);
    void onEnter() override;
    void onExit() override;
    void update(float dt) override;
    void draw(sf::RenderWindow& window) override;
    void drawImGui() override;
};