#include "StateBalconySim.hpp"
#include "imgui.h"
#include <cmath>
#include <algorithm>

StateBalconySim::StateBalconySim(Application* app) : State(app) {
    m_sunScores.assign(m_balconGridSize.x * m_balconGridSize.y, 1.0f);
}
void StateBalconySim::onEnter() {
    recalculerOmbres();
}
void StateBalconySim::onExit() {}

void StateBalconySim::recalculerOmbres() {
    m_sunScores.assign(m_balconGridSize.x * m_balconGridSize.y, 1.0f);
    const auto& murs = m_app->getUserBalcony().getMesMursRef();
    
    // Angle du soleil (simplifié : 6h = gauche, 12h = haut, 18h = droite)
    float angleRad = (m_heureDuJour - 6.0f) * 3.14159f / 12.0f;
    sf::Vector2f dirSoleil(-std::cos(angleRad), -std::sin(angleRad));

    for (int y = 0; y < m_balconGridSize.y; ++y) {
        for (int x = 0; x < m_balconGridSize.x; ++x) {
            sf::Vector2f posCase(x, y);
            
            // On lance un rayon de la case vers le soleil
            // On vérifie 20 points le long du rayon pour voir s'ils tapent un mur
            for (float d = 1.0f; d < 30.0f; d += 1.0f) {
                int testX = (int)(x + dirSoleil.x * d);
                int testY = (int)(y + dirSoleil.y * d);
                
                sf::Vector2i testPos(testX, testY);
                if (std::find(murs.begin(), murs.end(), testPos) != murs.end()) {
                    m_sunScores[y * m_balconGridSize.x + x] = 0.2f; // Case à l'ombre
                    break;
                }
            }
        }
    }
}

void StateBalconySim::update(float dt) {
    if (m_currentMode == EditMode::OBSERVER) return; // Rien à faire

    // On ignore les clics si ImGui utilise la souris
    if (ImGui::GetIO().WantCaptureMouse) return;

    sf::Vector2i mousePos = sf::Mouse::getPosition(m_app->getWindow());
    
    // Calcul de la coordonnée sur la grille
    int gridX = std::floor((mousePos.x - m_balconPos.x) / m_gridCellSize);
    int gridY = std::floor((mousePos.y - m_balconPos.y) / m_gridCellSize);

    // Vérifie qu'on clique bien DANS le balcon
    bool insideGrid = (gridX >= 0 && gridX < m_balconGridSize.x && gridY >= 0 && gridY < m_balconGridSize.y);

    if (insideGrid) {
        // --- NOUVEAU : On accède aux murs du profil ---
        auto& mursProfil = m_app->getUserBalcony().getMesMursRef();
        bool dataChanged = false;

        // Clic Gauche : Placer
        if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
            if (m_currentMode == EditMode::PLACER_PLANTE && m_selectedPlantIndex >= 0) {
                // BUG FIX : On accède à la référence de la plante par son INDEX UNIQUE dans le vecteur
                auto& plantes = m_app->getUserBalcony().getMesPlantesRef();
                // Même si deux plantes ont le même nom, plantes[i] désigne bien une instance unique !
                plantes[m_selectedPlantIndex].position_balcon = sf::Vector2f(gridX * m_gridCellSize, gridY * m_gridCellSize);
                dataChanged = true;
            }
            else if (m_currentMode == EditMode::DESSINER_MUR) {
                sf::Vector2i newMur(gridX, gridY);
                // Correction : On utilise mursProfil au lieu de m_murs
                if (std::find(mursProfil.begin(), mursProfil.end(), newMur) == mursProfil.end()) {
                    mursProfil.push_back(newMur);
                    dataChanged = true;
                }
            }
        }
        // Clic Droit : Effacer (pour les murs)
        else if (sf::Mouse::isButtonPressed(sf::Mouse::Right)) {
            if (m_currentMode == EditMode::DESSINER_MUR) {
                sf::Vector2i target(gridX, gridY);
                auto it = std::remove(mursProfil.begin(), mursProfil.end(), target);
                if (it != mursProfil.end()) {
                    mursProfil.erase(it, mursProfil.end());
                    dataChanged = true;
                }
            }
        }

        // Si on a modifié quelque chose, on sauvegarde d'un coup !
        if (dataChanged) {
            m_app->getUserBalcony().sauvegarderProfil("mon_balcon.json");
        }
    }
    recalculerOmbres();
}

void StateBalconySim::draw(sf::RenderWindow& window) {
    float width = m_balconGridSize.x * m_gridCellSize;
    float height = m_balconGridSize.y * m_gridCellSize;

    // 1. Le sol (Béton)
    sf::RectangleShape floor(sf::Vector2f(width, height));
    floor.setPosition(m_balconPos);
    floor.setFillColor(sf::Color(70, 75, 70));
    floor.setOutlineThickness(2.f);
    floor.setOutlineColor(sf::Color(40, 45, 40));
    window.draw(floor);

    // 2. La Grille de 5x5 cm
    sf::RectangleShape line;
    line.setFillColor(sf::Color(255, 255, 255, 30));
    for (int x = 0; x <= m_balconGridSize.x; ++x) {
        line.setSize(sf::Vector2f(1.f, height));
        line.setPosition(m_balconPos.x + x * m_gridCellSize, m_balconPos.y);
        window.draw(line);
    }
    for (int y = 0; y <= m_balconGridSize.y; ++y) {
        line.setSize(sf::Vector2f(width, 1.f));
        line.setPosition(m_balconPos.x, m_balconPos.y + y * m_gridCellSize);
        window.draw(line);
    }

    // 3. Les Murs (en gris foncé) --- NOUVEAU : On lit ceux du profil ---
    sf::RectangleShape wallRect(sf::Vector2f(m_gridCellSize, m_gridCellSize));
    wallRect.setFillColor(sf::Color(30, 30, 30));
    const auto& murs = m_app->getUserBalcony().getMesMursRef(); // On lit les vrais murs
    for (const auto& mur : murs) {
        wallRect.setPosition(m_balconPos.x + mur.x * m_gridCellSize, m_balconPos.y + mur.y * m_gridCellSize);
        window.draw(wallRect);
    }

    // 4. Les Plantes !
    sf::CircleShape plantShape;
    const auto& plantes = m_app->getUserBalcony().getMesPlantes();
    for (int i = 0; i < plantes.size(); ++i) {
        const auto& p = plantes[i];
        
        if (p.position_balcon.x >= 0.0f) {
            float radius = std::max(m_gridCellSize * 0.5f, std::sqrt((float)p.volume_pot_actuel_L) * 3.0f);
            plantShape.setRadius(radius);
            plantShape.setOrigin(radius, radius); 
            plantShape.setPosition(
                m_balconPos.x + p.position_balcon.x + m_gridCellSize * 0.5f, 
                m_balconPos.y + p.position_balcon.y + m_gridCellSize * 0.5f
            );
            
            // BUG FIX : On compare l'INDEX unique de la plante pour la surbrillance
            if (m_currentMode == EditMode::PLACER_PLANTE && m_selectedPlantIndex == i) {
                plantShape.setFillColor(sf::Color(100, 255, 120));
                plantShape.setOutlineThickness(2.f);
                plantShape.setOutlineColor(sf::Color::White);
            } else {
                plantShape.setFillColor(sf::Color(60, 150, 80));
                plantShape.setOutlineThickness(1.f);
                plantShape.setOutlineColor(sf::Color(30, 90, 40));
            }
            window.draw(plantShape);
        }
    }
    if (!m_sunScores.empty()) {
        sf::RectangleShape heatRect(sf::Vector2f(m_gridCellSize, m_gridCellSize));
        for (int y = 0; y < m_balconGridSize.y; ++y) {
            for (int x = 0; x < m_balconGridSize.x; ++x) {
                int index = y * m_balconGridSize.x + x;
                float score = m_sunScores[index];
                heatRect.setPosition(m_balconPos.x + x * m_gridCellSize, m_balconPos.y + y * m_gridCellSize);
                
                // Couleur : Jaune si soleil (1.0), Gris bleu si ombre (0.2)
                heatRect.setFillColor(sf::Color(255, 255, 150, (sf::Uint8)(score * 80))); 
                window.draw(heatRect);
            }
        }
    }
    // Dans draw(), juste pour tester :
    sf::Vertex sunLine[] = {
        sf::Vertex(sf::Vector2f(50, 50), sf::Color::Yellow),
        sf::Vertex(sf::Vector2f(50 + std::cos((m_heureDuJour-6)*3.14/12)*30, 
                                50 + std::sin((m_heureDuJour-6)*3.14/12)*30), sf::Color::Yellow)
    };
    window.draw(sunLine, 2, sf::Lines);
}

void StateBalconySim::drawImGui() {
    // Boîte à outils latérale (comme avant)
    ImGui::SetNextWindowPos(ImVec2(20, 20));
    ImGui::SetNextWindowSize(ImVec2(300, (float)m_app->getWindow().getSize().y - 40));
    ImGui::Begin("Boite a outils", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove);

    if (ImGui::Button("< Retour Menu", ImVec2(-1, 40))) {
        m_app->getStateMachine().removeState();
    }
    
    ImGui::Dummy(ImVec2(0, 10));
    ImGui::TextColored(ImVec4(0.9f, 0.7f, 0.2f, 1.f), "1. Outils d'edition");
    ImGui::Separator();
    
    int mode = (int)m_currentMode;
    ImGui::RadioButton("Observer", &mode, 0);
    ImGui::RadioButton("Placer une Plante", &mode, 1);
    ImGui::RadioButton("Dessiner Mur/Rambarde", &mode, 2);
    m_currentMode = (EditMode)mode;

    ImGui::Dummy(ImVec2(0, 15));

    if (m_currentMode == EditMode::DESSINER_MUR) {
        ImGui::TextColored(ImVec4(0.5f, 0.8f, 0.5f, 1.f), "Outil Mur selectionne :");
        ImGui::TextWrapped("- Clic Gauche : Placer un bloc (5x5cm)");
        ImGui::TextWrapped("- Clic Droit : Effacer un bloc");
    }
    else if (m_currentMode == EditMode::PLACER_PLANTE) {
        ImGui::TextColored(ImVec4(0.5f, 0.8f, 0.5f, 1.f), "Selectionnez une plante :");
        ImGui::BeginChild("ListePlantes", ImVec2(0, 0), true);
        
        // BUG FIX : On utilise les plantes du profil utilisateur
        auto& plantes = m_app->getUserBalcony().getMesPlantesRef();
        if (plantes.empty()) {
            ImGui::TextWrapped("Aucune plante. Allez dans le Wiki pour en adopter !");
        } else {
            for (int i = 0; i < plantes.size(); ++i) {
                // Création d'un élément cliquable UNIQUE pour chaque instance physique (car i est unique)
                if (ImGui::Selectable((plantes[i].surnom + "##" + std::to_string(i)).c_str(), m_selectedPlantIndex == i)) {
                    m_selectedPlantIndex = i; // On mémorise l'index de la plante
                }
            }
        }
        ImGui::EndChild();
    }
    else {
        ImGui::TextWrapped("Mode observation. Explorez votre balcon !");
        ImGui::Dummy(ImVec2(0, 20));
        ImGui::TextColored(ImVec4(0.9f, 0.7f, 0.2f, 1.f), "Course du soleil (WIP)");
        ImGui::SliderFloat("Heure", &m_heureDuJour, 6.0f, 20.0f, "%.1f h");
    }

    ImGui::End();
}