#include "StateBalconySim.hpp"
#include "Core/Application.hpp"
#include "Services/SunCalculator.hpp"
#include <imgui.h>
#include <cmath>
#include <algorithm>
#include <iostream>

// --- SHADER 1 : Le Solveur GPU de Ray-casting ---
const std::string raycastShaderCode = R"(
uniform sampler2D u_walls;
uniform vec2 u_sunDir;
uniform float u_tanElev;
uniform float u_hasRoof;
uniform vec2 u_resolution;
uniform float u_cellSize;

void main() {
    vec2 uv = gl_TexCoord[0].xy;
    vec2 pixelCoord = floor(uv * u_resolution) + 0.5;

    // Si on est sur un mur, pas de soleil au sol
    vec4 myWall = texture2D(u_walls, uv);
    if (myWall.r > 0.5) {
        gl_FragColor = vec4(0.0);
        return;
    }

    // Ombre du toit (3D)
    if (u_hasRoof > 0.5) {
        float distHoriz = 2.5 / u_tanElev;
        vec2 source = pixelCoord * u_cellSize + u_sunDir * distHoriz;
        if (source.x >= 0.0 && source.x < u_resolution.x * u_cellSize &&
            source.y >= 0.0 && source.y < u_resolution.y * u_cellSize) {
            gl_FragColor = vec4(0.0);
            return;
        }
    }

    // Raycasting en GPU avec pas de 0.25 (anti-fuites diagonales)
    vec2 pos = pixelCoord;
    vec2 step = u_sunDir * 0.25;
    float d = 0.25;

    for (int i = 0; i < 200; i++) {
        pos += step;
        if (pos.x < 0.0 || pos.x >= u_resolution.x || pos.y < 0.0 || pos.y >= u_resolution.y) break;

        vec4 wall = texture2D(u_walls, pos / u_resolution);
        if (wall.r > 0.5) {
            float h = wall.g * 5.0; // Décompression de la hauteur (0-5m)
            if (h / (d * u_cellSize) > u_tanElev) {
                gl_FragColor = vec4(0.0);
                return;
            }
        }
        d += 0.25;
    }

    // Le soleil touche ! On accumule 0.5 heure (1/255 de rouge)
    gl_FragColor = vec4(0.0039215, 0.0, 0.0, 0.0); 
}
)";

// --- SHADER 2 : Affichage Palette de la Heatmap ---
const std::string heatmapShaderCode = R"(
uniform sampler2D u_sunmap;
uniform sampler2D u_walls;

void main() {
    vec2 uv = gl_TexCoord[0].xy;
    vec4 wall = texture2D(u_walls, uv);
    if (wall.r > 0.5) {
        gl_FragColor = vec4(0.0); // Murs invisibles dans la heatmap
        return;
    }

    // On lit l'accumulation (nb de /255) et on multiplie par 0.5 (demi-heure)
    float hours = texture2D(u_sunmap, uv).r * 255.0 * 0.5;
    vec4 col = vec4(0.0);

    if (hours > 0.1) {
        if (hours < 2.0)       col = vec4(0.157, 0.235, 0.706, 0.627); // Bleu
        else if (hours < 5.0)  col = vec4(0.235, 0.706, 0.314, 0.627); // Vert
        else                   col = vec4(0.980, 0.863, 0.157, 0.627); // Jaune
    }
    gl_FragColor = col;
}
)";
StateBalconySim::StateBalconySim(Application* app) : State(app) {
    m_cfg.width = 40;
    m_cfg.height = 30;
    m_cfg.grid.resize(m_cfg.height, std::vector<GridCell>(m_cfg.width));

    // Compilation des shaders GPU
    if (sf::Shader::isAvailable()) {
        if (m_raycastShader.loadFromMemory(raycastShaderCode, sf::Shader::Fragment) &&
            m_heatmapShader.loadFromMemory(heatmapShaderCode, sf::Shader::Fragment)) {
            
            m_sunmapTexture.create(m_cfg.width, m_cfg.height);
            m_sunmapTexture.setSmooth(false); 
            m_shadersLoaded = true;
        }
    }
}
void StateBalconySim::updateGridVertices() {
    m_gridVertices.setPrimitiveType(sf::Quads); // On dessine des carrés (4 sommets)
    m_gridVertices.resize(m_cfg.width * m_cfg.height * 4);

    for (int r = 0; r < m_cfg.height; ++r) {
        for (int c = 0; c < m_cfg.width; ++c) {
            int index = (r * m_cfg.width + c) * 4;

            // Position locale de la cellule (le -1.0f laisse 1 pixel de marge pour faire le quadrillage noir)
            float x = c * CELL_PX;
            float y = r * CELL_PX;
            float size = CELL_PX - 1.0f;

            m_gridVertices[index + 0].position = sf::Vector2f(x, y);
            m_gridVertices[index + 1].position = sf::Vector2f(x + size, y);
            m_gridVertices[index + 2].position = sf::Vector2f(x + size, y + size);
            m_gridVertices[index + 3].position = sf::Vector2f(x, y + size);

            // Calcul de la couleur
            sf::Color color;
            const auto& gc = m_cfg.grid[r][c];
            if (gc.isWall) {
                float hT = std::clamp((gc.wallHeight - 0.5f) / 3.5f, 0.f, 1.f);
                color = sf::Color(80 + (int)(hT * 60), 60, 30);
            } else {
                color = sf::Color(45, 50, 45); // Sol classique
            }

            // On applique la couleur aux 4 coins du carré
            for (int i = 0; i < 4; i++) {
                m_gridVertices[index + i].color = color;
            }
        }
    }
}

void StateBalconySim::onEnter() {
    m_cfg = m_app->getUserBalcony().getBalconyConfigRef();
    m_cfg.syncRealDate();
    
    recalcSun();
    updateWallTexture(); 
    updateGridVertices(); // <-- NOUVEAU : On prépare la grille 2D
    markSunMapDirty();
}

void StateBalconySim::onExit() {}

void StateBalconySim::update(float dt) {
    if (m_sunMapDirty && m_shadersLoaded) {
        computeSunMapGPU();
        m_sunMapDirty = false;
    }
    handleInput();
}

void StateBalconySim::updateWallTexture() {
    sf::Image img;
    img.create(m_cfg.width, m_cfg.height, sf::Color::Black);
    for (int r = 0; r < m_cfg.height; ++r) {
        for (int c = 0; c < m_cfg.width; ++c) {
            if (m_cfg.grid[r][c].isWall) {
                float h = std::clamp(m_cfg.grid[r][c].wallHeight, 0.0f, 5.0f);
                sf::Uint8 g = static_cast<sf::Uint8>((h / 5.0f) * 255.0f);
                img.setPixel(c, r, sf::Color(255, g, 0, 255)); // R = Mur?, G = Hauteur compressée
            }
        }
    }
    m_wallTexture.loadFromImage(img);
    m_wallTexture.setSmooth(false);
}

void StateBalconySim::computeSunMapGPU() {
    m_sunmapTexture.clear(sf::Color::Transparent);
    sf::Sprite passSprite(m_wallTexture);
    float savedHour = m_cfg.hour;

    for (float h = 6.0f; h <= 20.0f; h += 0.5f) {
        m_cfg.hour = h;
        SunPosition sun = SunCalculator::compute(m_cfg);
        if (!sun.isAboveHorizon()) continue;

        float bAz = static_cast<float>(m_cfg.orientation) * 45.0f;
        float relAz = (sun.azimuth - bAz) * 3.14159265f / 180.0f;
        sf::Vector2f sunDir(-std::sin(relAz), std::cos(relAz));
        float tanElev = std::tan(sun.elevation * 3.14159265f / 180.0f);

        m_raycastShader.setUniform("u_walls", m_wallTexture);
        m_raycastShader.setUniform("u_sunDir", sunDir);
        m_raycastShader.setUniform("u_tanElev", tanElev);
        m_raycastShader.setUniform("u_hasRoof", m_cfg.hasRoof ? 1.0f : 0.0f);
        m_raycastShader.setUniform("u_resolution", sf::Vector2f((float)m_cfg.width, (float)m_cfg.height));
        m_raycastShader.setUniform("u_cellSize", 0.05f);

        sf::RenderStates states;
        states.shader = &m_raycastShader;
        states.blendMode = sf::BlendAdd; // Le fameux Blend Add pour accumuler les heures

        m_sunmapTexture.draw(passSprite, states);
    }
    m_sunmapTexture.display();

    m_cfg.hour = savedHour;
    recalcSun();
}

void StateBalconySim::handleInput() {
    if (ImGui::GetIO().WantCaptureMouse) return;

    float gridW = m_cfg.width * CELL_PX;
    float gridH = m_cfg.height * CELL_PX;
    sf::Vector2f offset((m_app->getWindow().getSize().x - gridW) / 2.f, 
                        (m_app->getWindow().getSize().y - gridH) / 2.f);

    if (sf::Mouse::isButtonPressed(sf::Mouse::Left) || sf::Mouse::isButtonPressed(sf::Mouse::Right)) {
        sf::Vector2i mPos = sf::Mouse::getPosition(m_app->getWindow());
        int gx = static_cast<int>((mPos.x - offset.x) / CELL_PX);
        int gy = static_cast<int>((mPos.y - offset.y) / CELL_PX);

        if (gx >= 0 && gx < m_cfg.width && gy >= 0 && gy < m_cfg.height) {
            
            // Masque des plantes
            uint64_t row_plants_mask = 0;
            auto& plantes = m_app->getUserBalcony().getMesPlantesRef();
            for (const auto& p : plantes) {
                if (p.position_balcon.x >= 0.0f) { 
                    int px = static_cast<int>(p.position_balcon.x / CELL_PX);
                    int py = static_cast<int>(p.position_balcon.y / CELL_PX);
                    if (py == gy && px >= 0 && px < m_cfg.width) {
                        row_plants_mask |= (1ULL << px);
                    }
                }
            }

            bool modified = false;

            if (m_editMode == 0) { // Mur
                if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
                    if ((row_plants_mask & (1ULL << gx)) == 0) { 
                        m_cfg.grid[gy][gx].isWall = true;
                        m_cfg.grid[gy][gx].wallHeight = m_cfg.defaultWallHeight;
                        modified = true;
                    }
                } else if (sf::Mouse::isButtonPressed(sf::Mouse::Right)) {
                    m_cfg.grid[gy][gx].isWall = false;
                    modified = true;
                }
            } 
            else if (m_editMode == 2 && m_selectedPlantIndex >= 0) { // Plante
                 if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
                     if (!m_cfg.grid[gy][gx].isWall) {
                         plantes[m_selectedPlantIndex].position_balcon = sf::Vector2f(gx * CELL_PX, gy * CELL_PX);
                         m_app->getUserBalcony().sauvegarderProfil("mon_balcon.json");
                     }
                 } else if (sf::Mouse::isButtonPressed(sf::Mouse::Right)) {
                     plantes[m_selectedPlantIndex].position_balcon = sf::Vector2f(-100.f, -100.f);
                     m_app->getUserBalcony().sauvegarderProfil("mon_balcon.json");
                 }
            }
            
            if (modified) {
                updateWallTexture(); 
                updateGridVertices(); // <-- NOUVEAU : On met à jour les sommets car un mur a changé
                markSunMapDirty();
                m_app->getUserBalcony().getBalconyConfigRef() = m_cfg;
                m_app->getUserBalcony().sauvegarderProfil("mon_balcon.json");
            }
        }
    }
}

// ============================================================
//  RENDU
// ============================================================

void StateBalconySim::draw(sf::RenderWindow& window) {
    float gridW = m_cfg.width * CELL_PX;
    float gridH = m_cfg.height * CELL_PX;
    sf::Vector2f offset((window.getSize().x - gridW) / 2.f, (window.getSize().y - gridH) / 2.f);

    renderGrid(window, offset);
    if (m_showShadows) renderShadowLayer(window, offset);
    if (m_showSunMap)  renderSunMapLayer(window, offset);
    renderPlants(window, offset);
}

void StateBalconySim::renderGrid(sf::RenderWindow& window, sf::Vector2f offset) {
    // On crée un "état de rendu" pour décaler tout le dessin d'un seul coup (le centrage)
    sf::RenderStates states;
    states.transform.translate(offset);
    
    // BOUM : 1 seul appel à la carte graphique !
    window.draw(m_gridVertices, states); 
}

void StateBalconySim::renderShadowLayer(sf::RenderWindow& window, sf::Vector2f offset) {
    if (!m_sun.isAboveHorizon()) return;

    sf::RectangleShape shadow(sf::Vector2f(CELL_PX, CELL_PX));
    shadow.setFillColor(sf::Color(0, 0, 0, 150)); // Ombre pure, précise et scientifique

    for (int r = 0; r < m_cfg.height; ++r) {
        for (int c = 0; c < m_cfg.width; ++c) {
            if (!m_cfg.grid[r][c].isWall && SunCalculator::isInShadow(m_cfg, c, r, m_sun)) {
                shadow.setPosition(offset.x + c * CELL_PX, offset.y + r * CELL_PX);
                window.draw(shadow);
            }
        }
    }
}

void StateBalconySim::renderSunMapLayer(sf::RenderWindow& window, sf::Vector2f offset) {
    if (!m_shadersLoaded) return;

    // Un seul rectangle étiré sur tout le balcon, le GPU fait le coloriage !
    sf::RectangleShape heatRect(sf::Vector2f(m_cfg.width * CELL_PX, m_cfg.height * CELL_PX));
    heatRect.setPosition(offset);

    m_heatmapShader.setUniform("u_sunmap", m_sunmapTexture.getTexture());
    m_heatmapShader.setUniform("u_walls", m_wallTexture);

    window.draw(heatRect, &m_heatmapShader);
}

void StateBalconySim::renderPlants(sf::RenderWindow& window, sf::Vector2f offset) {
    sf::CircleShape plantShape;
    const auto& plantes = m_app->getUserBalcony().getMesPlantes();
    
    for (int i = 0; i < (int)plantes.size(); ++i) {
        const auto& p = plantes[i];
        if (p.position_balcon.x >= 0.0f) {
            float radius = std::max(CELL_PX * 0.4f, std::sqrt((float)p.volume_pot_actuel_L) * 2.0f);
            plantShape.setRadius(radius);
            plantShape.setOrigin(radius, radius); 
            plantShape.setPosition(offset.x + p.position_balcon.x + CELL_PX * 0.5f, 
                                   offset.y + p.position_balcon.y + CELL_PX * 0.5f);
            
            if (m_editMode == 2 && m_selectedPlantIndex == i) {
                plantShape.setFillColor(sf::Color(100, 255, 120));
                plantShape.setOutlineThickness(2.f);
                plantShape.setOutlineColor(sf::Color::White);
            } else {
                plantShape.setFillColor(sf::Color(60, 150, 80));
                plantShape.setOutlineThickness(1.f);
                plantShape.setOutlineColor(sf::Color(30, 90, 40));
            }
            window.draw(plantShape);
        }
    }
}

// ============================================================
//  INTERFACE
// ============================================================

void StateBalconySim::drawImGui() {
    ImGui::Begin("🛠️ Atelier du Balcon", nullptr, ImGuiWindowFlags_AlwaysAutoResize);

    if (ImGui::Button("< Menu")) m_app->getStateMachine().removeState();
    
    if (ImGui::CollapsingHeader("🧭 Boussole (Nord en haut)", ImGuiTreeNodeFlags_DefaultOpen)) {
        drawCompass();
    }

    if (ImGui::CollapsingHeader("🔨 Outils", ImGuiTreeNodeFlags_DefaultOpen)) {
        const char* modes[] = { "Murs", "Observation", "Plantes" };
        ImGui::Combo("Mode", &m_editMode, modes, IM_ARRAYSIZE(modes));
        
        if (m_editMode == 0) {
            ImGui::SliderFloat("H. Mur", &m_cfg.defaultWallHeight, 0.5f, 4.0f, "%.1f m");
        } else if (m_editMode == 2) {
            auto& plantes = m_app->getUserBalcony().getMesPlantesRef();
            for (int i = 0; i < (int)plantes.size(); i++) {
                if (ImGui::Selectable((plantes[i].surnom + "##" + std::to_string(i)).c_str(), m_selectedPlantIndex == i))
                    m_selectedPlantIndex = i;
            }
        }
    }

    if (ImGui::CollapsingHeader("🏠 Structure")) {
        if (ImGui::Checkbox("Toit (Balcon du haut)", &m_cfg.hasRoof)) {
            markSunMapDirty();
            m_app->getUserBalcony().getBalconyConfigRef() = m_cfg;
            m_app->getUserBalcony().sauvegarderProfil("mon_balcon.json");
        }
    }

    if (ImGui::CollapsingHeader("☀️ Simulation")) {
        if (ImGui::SliderFloat("Heure", &m_cfg.hour, 0.f, 23.9f, "%.1f h")) recalcSun();
        ImGui::Checkbox("Afficher Ombres", &m_showShadows);
        if (ImGui::Checkbox("Afficher Heatmap", &m_showSunMap)) markSunMapDirty();
    }

    ImGui::End();
}

void StateBalconySim::drawCompass() {
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImVec2 center = ImGui::GetCursorScreenPos();
    center.x += 60; center.y += 60;
    float radius = 50.0f;

    draw->AddCircle(center, radius, IM_COL32(200, 200, 200, 255), 32, 2.0f);
    
    const char* labels[] = {"N","NE","E","SE","S","SW","W","NW"};
    for (int i = 0; i < 8; ++i) {
        float angle = (i * 45.0f - 90.0f) * (3.14159f / 180.0f);
        ImVec2 p(center.x + std::cos(angle) * radius, center.y + std::sin(angle) * radius);
        
        ImGui::SetCursorScreenPos(ImVec2(p.x - 12, p.y - 12));
        if (ImGui::Button((std::string(labels[i]) + "##c").c_str(), ImVec2(24, 24))) {
            m_cfg.orientation = static_cast<BalconyOrientation>(i);
            markSunMapDirty();
            m_app->getUserBalcony().getBalconyConfigRef() = m_cfg;
            m_app->getUserBalcony().sauvegarderProfil("mon_balcon.json");
        }
    }
    ImGui::Dummy(ImVec2(120, 120));
}

void StateBalconySim::recalcSun() {
    m_sun = SunCalculator::compute(m_cfg);
}

void StateBalconySim::markSunMapDirty() {
    m_sunMapDirty = true;
}