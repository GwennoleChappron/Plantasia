#pragma once
#include <vector>
#include <string>
#include <ctime>
#include <SFML/System/Vector2.hpp>
#include <nlohmann/json.hpp>

enum class BalconyOrientation { North = 0, NorthEast, East, SouthEast, South, SouthWest, West, NorthWest };

struct GridCell {
    bool  isWall       = false;
    float wallHeight   = 2.5f;
    float sunHours     = 0.0f;
};

struct BalconyConfig {
    // --- NOUVEAU : Dimensions dynamiques ---
    int width = 40;
    int height = 30;

    float latitude  = 48.5f;
    float longitude = 7.75f;
    BalconyOrientation orientation = BalconyOrientation::South;

    int   year = 2026;
    int   month = 3;
    int   day = 27;
    float hour = 12.0f;

    bool hasRoof = false; //
    float roofOpacity = 0.8f;

    // --- GRILLE DYNAMIQUE ---
    // On utilise un vector de vector pour pouvoir changer la taille plus tard
    std::vector<std::vector<GridCell>> grid;

    float defaultWallHeight = 2.5f;

    void syncRealDate() {
        std::time_t t = std::time(nullptr);
        std::tm* tm   = std::localtime(&t);
        year  = tm->tm_year + 1900;
        month = tm->tm_mon  + 1;
        day   = tm->tm_mday;
    }
};
// Note : On n'a plus besoin de to_json/from_json pour GridCell !

inline void to_json(nlohmann::json& j, const BalconyConfig& cfg) {
    j = nlohmann::json{
        {"width", cfg.width},
        {"height", cfg.height},
        {"orientation", static_cast<int>(cfg.orientation)},
        {"hasRoof", cfg.hasRoof},
        {"defaultWallHeight", cfg.defaultWallHeight},
        {"latitude", cfg.latitude}
    };

    // --- 🗜️ COMPRESSION BIT À BIT ---
    std::vector<uint64_t> walls_mask;
    std::vector<float> walls_heights; 

    for (int r = 0; r < cfg.height; ++r) {
        uint64_t row_bits = 0; // Un entier de 64 bits rempli de 0
        for (int c = 0; c < cfg.width; ++c) {
            if (cfg.grid[r][c].isWall) {
                // On allume le bit à la position 'c'
                row_bits |= (1ULL << c); 
                // On sauvegarde la hauteur uniquement pour ce mur
                walls_heights.push_back(cfg.grid[r][c].wallHeight);
            }
        }
        walls_mask.push_back(row_bits); // On sauvegarde le nombre qui représente toute la ligne
    }

    j["walls_mask"] = walls_mask;
    j["walls_heights"] = walls_heights;
}

inline void from_json(const nlohmann::json& j, BalconyConfig& cfg) {
    cfg.width = j.value("width", 40);
    cfg.height = j.value("height", 30);
    cfg.orientation = static_cast<BalconyOrientation>(j.value("orientation", 4)); 
    cfg.hasRoof = j.value("hasRoof", false);
    cfg.defaultWallHeight = j.value("defaultWallHeight", 1.0f);
    cfg.latitude = j.value("latitude", 48.58f); 

    // On prépare une grille vide
    cfg.grid.assign(cfg.height, std::vector<GridCell>(cfg.width));

    // --- 🔓 DÉCOMPRESSION BIT À BIT ---
    if (j.contains("walls_mask")) {
        auto bitmask = j["walls_mask"].get<std::vector<uint64_t>>();
        auto heights = j.value("walls_heights", std::vector<float>());
        
        int height_idx = 0; // Pour piocher la bonne hauteur dans notre tableau clairsemé

        for (int r = 0; r < cfg.height && r < bitmask.size(); ++r) {
            uint64_t row_bits = bitmask[r];
            for (int c = 0; c < cfg.width; ++c) {
                
                // Si le bit à la position 'c' est allumé (vaut 1)
                if (row_bits & (1ULL << c)) { 
                    cfg.grid[r][c].isWall = true;
                    // On récupère sa hauteur, ou on met la valeur par défaut par sécurité
                    if (height_idx < heights.size()) {
                        cfg.grid[r][c].wallHeight = heights[height_idx++];
                    } else {
                        cfg.grid[r][c].wallHeight = cfg.defaultWallHeight;
                    }
                } else {
                    cfg.grid[r][c].isWall = false;
                    cfg.grid[r][c].wallHeight = 0.0f;
                }
            }
        }
    }
}