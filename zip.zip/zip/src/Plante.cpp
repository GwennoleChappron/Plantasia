#include "Plante.hpp"

Plante::Plante(const std::string& n, Rusticite r, ExpositionSoleil s, ExpositionVent v)
    : nom(n), rusticite(r), exposition_soleil(s), exposition_vent(v) {}

void Plante::afficher() const {
    std::cout << "----- 🌿 " << nom << " (" << rusticite << ") -----\n";
    std::cout << "Exposition : " << exposition_soleil << "\n";
    std::cout << "Exposition au vent : " << exposition_vent << "\n";
}

std::ostream& operator<<(std::ostream& os, const Rusticite& r) {
    switch (r) {
        case Rusticite::RUSTIQUE: os << "Rustique"; break;
        case Rusticite::SEMI_RUSTIQUE: os << "Semi-rustique"; break;
        case Rusticite::FRAGILE: os << "Fragile"; break;
        case Rusticite::GELIVE: os << "Gélive"; break;
        case Rusticite::TROPICALE: os << "Tropicale"; break;
    }
    return os;
}
std::ostream& operator<<(std::ostream& os, const ExpositionSoleil& e) {
    switch (e) {
        case ExpositionSoleil::PLEIN_SOLEIL: os << "Plein soleil"; break;
        case ExpositionSoleil::MI_OMBRE: os << "Mi-ombre"; break;
        case ExpositionSoleil::OMBRE_CLAIRE: os << "Ombre claire"; break;
        case ExpositionSoleil::OMBRE_DENSE: os << "Ombre dense"; break;
    }
    return os;
}
std::ostream& operator<<(std::ostream& os, const ExpositionVent& e) {
    switch (e) {
        case ExpositionVent::ABRITE: os << "Abrité"; break;
        case ExpositionVent::MODERE: os << "Modéré"; break;
        case ExpositionVent::COULOIR_DE_VENT: os << "Couloir de vent"; break;
    }
    return os;
}