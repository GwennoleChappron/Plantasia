#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <nlohmann/json.hpp>

// On définit les enums d'abord
enum class Rusticite { RUSTIQUE, SEMI_RUSTIQUE, FRAGILE, GELIVE, TROPICALE };
enum class ExpositionSoleil { PLEIN_SOLEIL, MI_OMBRE, OMBRE_CLAIRE, OMBRE_DENSE };
enum class ExpositionVent { ABRITE, MODERE, COULOIR_DE_VENT };

// IMPORTANT : Les macros de sérialisation des ENUMS doivent être AVANT la classe
NLOHMANN_JSON_SERIALIZE_ENUM( Rusticite, {
    {Rusticite::RUSTIQUE, "RUSTIQUE"},
    {Rusticite::SEMI_RUSTIQUE, "SEMI_RUSTIQUE"},
    {Rusticite::FRAGILE, "FRAGILE"},
    {Rusticite::GELIVE, "GELIVE"},
    {Rusticite::TROPICALE, "TROPICALE"}
})

NLOHMANN_JSON_SERIALIZE_ENUM( ExpositionSoleil, {
    {ExpositionSoleil::PLEIN_SOLEIL, "PLEIN_SOLEIL"},
    {ExpositionSoleil::MI_OMBRE, "MI_OMBRE"},
    {ExpositionSoleil::OMBRE_CLAIRE, "OMBRE_CLAIRE"},
    {ExpositionSoleil::OMBRE_DENSE, "OMBRE_DENSE"}
})

NLOHMANN_JSON_SERIALIZE_ENUM( ExpositionVent, {
    {ExpositionVent::ABRITE, "ABRITE"},
    {ExpositionVent::MODERE, "MODERE"},
    {ExpositionVent::COULOIR_DE_VENT, "COULOIR_DE_VENT"}
})

class Plante {
public:
    std::string nom;
    Rusticite rusticite;
    ExpositionSoleil exposition_soleil;
    ExpositionVent exposition_vent;

    Plante() = default; // Constructeur par défaut nécessaire pour le JSON
    Plante(const std::string& n, Rusticite r, ExpositionSoleil s, ExpositionVent v);
    std::string getNom() const { return nom; }
    void afficher() const;
};

// LES FONCTIONS MAGIQUES (Doivent être dans le même namespace que Plante)
inline void to_json(nlohmann::json& j, const Plante& p) {
    j = nlohmann::json{
        {"nom", p.nom},
        {"rusticite", p.rusticite},
        {"exposition_soleil", p.exposition_soleil},
        {"exposition_vent", p.exposition_vent}
    };
}

inline void from_json(const nlohmann::json& j, Plante& p) {
    j.at("nom").get_to(p.nom);
    j.at("rusticite").get_to(p.rusticite);
    j.at("exposition_soleil").get_to(p.exposition_soleil);
    j.at("exposition_vent").get_to(p.exposition_vent);
}

// Opérateurs d'affichage
std::ostream& operator<<(std::ostream& os, const Rusticite& r);
std::ostream& operator<<(std::ostream& os, const ExpositionSoleil& e);
std::ostream& operator<<(std::ostream& os, const ExpositionVent& e);